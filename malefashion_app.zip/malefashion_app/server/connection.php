<?php
$conn = mysqli_connect("localhost", "root", "", "malefashion_app")
    or die("Can't connect to the database");
